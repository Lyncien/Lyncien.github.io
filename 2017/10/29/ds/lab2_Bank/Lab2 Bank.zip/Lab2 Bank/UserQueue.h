/*
	Last Update time: 2017-10-17 
	Version��1.0
	Author��LinXiang (PB16020923) 
	Description��
		UserQueue.
*/
#include <stdlib.h>
#define QMAXSIZE 100
#define OK 1
#define ERROR 0 
typedef int Status;
typedef struct _User{
	int id; 
	int arrtime;
	int durtime;
	int amount;
}User;
typedef struct _SqQueue{
	User *base;
	int front;
	int rear;
}SqQueue;
Status InitQueue(SqQueue *q){//��ʼ������ 
	q->base=(User *)malloc(QMAXSIZE*sizeof(User));
	q->front=0;
	q->rear=0;
	return OK;
} 
Status DestoryQueue(SqQueue *q){//���ٶ��� 
	if(!q->base) return ERROR; 
	free(q->base);
	q->front=0;
	q->rear=0;
	return OK;
}
int QueueLength(SqQueue q){//����г��� 
	return (q.rear-q.front+QMAXSIZE) % QMAXSIZE;
}
Status EnQueue(SqQueue *q,User elem){//��� 
	if((q->rear+1) % QMAXSIZE==q->front) return ERROR;
	q->base[q->rear]=elem;
	q->rear=(q->rear+1) % QMAXSIZE;
	return OK;
}
Status DeQueue(SqQueue *q,User *elem){//���� 
	if(q->rear==q->front) return ERROR;
	*elem=q->base[q->front];
	q->front=(q->front+1) % QMAXSIZE;
	return OK;
}
Status PeekQueue(SqQueue *q,User *elem){//�鿴��ͷ�������� 
	if(q->rear==q->front) return ERROR;
	*elem=q->base[q->front];
	return OK;
}
Status PeekQueueByPos(SqQueue *q,int i,User *elem){//�鿴��i��Ԫ�ص������� 
	if(i>QueueLength(*q)) return ERROR;
	*elem=q->base[(q->front+i-1) % QMAXSIZE];
	return OK;
}
